### �lex Penina Aguilera ###

###Exercici 10

#Introdu�m el valor dels par�metres:
muA<-1
varA<-1
muB<-2
varB<-1
c<-0.2

#Modelitzem les variables A i B, tot simulant 100 observacions:
par(mfrow=c(1,1))
A<-ts(rnorm(100, mean=muA, sd=sqrt(varA)))
plot.ts(A,col=c(4))
B<-ts(rnorm(100, mean=muB, sd=sqrt(varB)))
plot.ts(B,col=c(4))

#Creem el proc�s estoc�stic a partir de A i B:
X<-ts(A*cos(c(1:100)*c)+B*sin(c(1:100)*c))
plot.ts(X,col=c(4))
#Observant el gr�fic del proc�s estoc�stic, observem una esp�cie de cicles, que es van repetint al llarg 
#de la serie (aproximadament cada 30 observacions). S�n deguts a la introducci� dels elements cosinus i sinus. 

#Observem tamb� el proc�s no �s estacionari de segon ordre. La mitjana no es mant� constant en cap moment, ja que 
#els cicles fan que aquesta augmenti i disminueixi peri�dicament. La vari�ncia tampoc es mant� constant, ja 
#que hi ha valors que estan situats molt distants, mentre que altres els observem relativament junts.

#Calculem la FAS i la FAP per a corroborar-ho:
par(mfrow=c(2,1))
acf(X,ylim=c(-1,1), lag=100)
pacf(X,ylim=c(-1,1), lag=100)
#Clarament observem com el proc�s no �s estacionari. Observem una FAS que oscil�la constantment, i una 
#FAP amb molts coeficients significatius.

