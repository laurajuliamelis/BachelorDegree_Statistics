### �lex Penina Aguilera ###

###Exercici 9

##S�rie A

#Indiquem quin �s el nostre directori de treball:
setwd("W:/An�lisi de S�ries Temporals")

#Introduim el fitxer amb les dades:
serieA<-ts(read.table("serie_a.txt")) 

#Fem un gr�fic de la s�rie per observar com es comporta:
par(mfrow=c(1,1))
plot.ts(serieA,col=c(4))
#Es tracta d'una s�rie estacion�ria, tant en mitjana com en vari�ncia. 

#Ho comprovem calculant la FAS i la FAP:
par(mfrow=c(2,1))
acf(serieA,ylim=c(-1,1))
pacf(serieA,ylim=c(-1,1))
#Efectivament, observem com el comportament de la FAS i la FAP corresponen al d'una serie estacion�ria.
#Ens decantem per un MA(1), ja que la FAP tendeix exponencialment cap a 0, mentre que la FAS tan sols t�
#un coeficient significatiu, tret del primer (no es conta perqu� indica la correlaci� del coeficient amb 
#ell mateix, i per aixo �s 1). 

#Aix� doncs, at�s a que no hem pr�s cap diferencia, ni hem observat cap component estacional, el model que 
#millor s'ajusta a la s�rie A �s el model MA(1).





###S�rie B

#Introduim el fitxer amb les dades:
serieB<-ts(read.table("serie_b.txt")) 

#Fem un gr�fic de la s�rie per observar com es comporta:
par(mfrow=c(1,1))
plot.ts(serieB,col=c(4))
#Sembla que la s�rie sigui estacion�ria en mitjana, per� no del tot en vari�ncia. 

#Sortirem de dubtes calculant la FAS i la FAP:
par(mfrow=c(2,1))
acf(serieB,ylim=c(-1,1))
pacf(serieB,ylim=c(-1,1))
#Observem un patr� oscil�latori en la FAS, fet que ens confirma que la serie no �s del tot estacion�ria.

#Per a arreglar-ho, prenem una difer�ncia regular (ordre 1):
dserieB<-diff(serieB)
par(mfrow=c(1,1))
plot.ts(dserieB,col=4)
#Sembla que la s�rie resultant �s estacion�ria tant en mitjana com en vari�ncia.

#Tornem a calcular la FAS i la FAP, per� aquest cop de la s�rie diferenciada:
par(mfrow=c(2,1))
acf(dserieB,ylim=c(-1,1))
pacf(dserieB,ylim=c(-1,1))
#Observem com els coeficients no s'acaben de netejar del tot. 

#Prenem una altra difer�ncia, aviam si ho solucionem:
ddserieB<-diff(dserieB)
par(mfrow=c(1,1))
plot.ts(ddserieB,col=4)

#Tornem a calcular la FAS i la FAP:
par(mfrow=c(2,1))
acf(ddserieB,ylim=c(-1,1))
pacf(ddserieB,ylim=c(-1,1))
#Ara s� s'observa clarament el comportament de la nostra s�rie temporal. Tant la FAS com la FAP tendeixen
#exponencialment cap a 0, fet que indica que el model adequat per a la nostra serie temporal �s un ARMA(1,1).
#Donat que hem aplicat 2 difer�ncies regulars a la s�rie original, tenim d=2. Per �ltim, cal recordar que 
#no hem observat cap component estacional en les dades.

#Aix�, el model adequat per a modelitzar la s�rie B �s un ARIMA(1,2,1).




